package com.pojoConfiguration;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class AppConfigurationTest {

	@Test
	void  test() {
		System.out.println("true");
	}

}
