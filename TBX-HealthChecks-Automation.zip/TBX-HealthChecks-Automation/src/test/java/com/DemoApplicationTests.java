package com;

import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.controller.ShallowChecksController;
import com.pojoConfiguration.AppConfiguration;
import com.service.RetrieveHealthCheckService;

@SpringBootTest
class DemoApplicationTests {
	@Autowired
  private ShallowChecksController shallowChecksController;
	@Autowired
	private AppConfiguration appConfiguration;
	@Autowired
	private RetrieveHealthCheckService retrievalHealthCheckService;
	
	public void getUsersTest() {
		//when(repository.findAll()).thenReturn(Stream.of(values)
		when(repository.findAll()).thenReturn(Stream.of(null))
	}
	
	
	@Test
	void contextLoads() {
	}

}
