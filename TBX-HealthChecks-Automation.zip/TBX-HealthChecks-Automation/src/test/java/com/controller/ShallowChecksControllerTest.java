package com.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ShallowChecksControllerTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
