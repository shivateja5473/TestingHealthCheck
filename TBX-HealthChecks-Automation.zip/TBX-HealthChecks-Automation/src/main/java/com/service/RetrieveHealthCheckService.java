package com.service;

public interface RetrieveHealthCheckService {

	public String getHC(String brand, String environment, String serviceName) throws Exception;
}
