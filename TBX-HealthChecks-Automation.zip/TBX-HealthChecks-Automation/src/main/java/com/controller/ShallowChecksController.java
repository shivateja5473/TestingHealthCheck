package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.serviceImpl.RetrieveHealthCheckServiceImpl;

@RestController
public class ShallowChecksController {
	@Autowired
	private RetrieveHealthCheckServiceImpl retrieveHealthCheckServiceImpl;
	
	
	@GetMapping("/{site}/{env}/{serviceName}")
	public ResponseEntity<String> getServiceHC(@PathVariable String site, 
			@PathVariable String env,
			@PathVariable String serviceName) throws Exception {
		
		return new ResponseEntity<String>(retrieveHealthCheckServiceImpl.getHC(site, env, serviceName), HttpStatus.OK);
		
	}
	
}
