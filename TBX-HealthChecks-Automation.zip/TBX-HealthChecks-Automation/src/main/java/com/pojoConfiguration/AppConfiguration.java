package com.pojoConfiguration;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration("com.pojoConfiguration.AppConfiguration")
@ConfigurationProperties("tbx")
public class AppConfiguration {
	private @Getter @Setter String site;
	private @Getter @Setter String env;
	private @Getter @Setter String ApiCart;
	private @Getter @Setter String ApiShop;
	private @Getter @Setter String ApiAvail;
	private @Getter @Setter String AvailSetup;
	private @Getter @Setter String Batches;
	private @Getter @Setter String CallCenter;
	private @Getter @Setter String ClientSetup;
	private @Getter @Setter String ContentSetup;
	private @Getter @Setter String CoreApiProduct;
	private @Getter @Setter String CoreApiRoomRate;
	private @Getter @Setter String DocumentSetup;
	private @Getter @Setter String FinanaceSetup;
	private @Getter @Setter String FlightSetup;
	private @Getter @Setter String FlightShop;
	private @Getter @Setter String MasterSetup;
	private @Getter @Setter String Monitoring;
	private @Getter @Setter String PackagedProductSetup;
	private @Getter @Setter String RecommendationApi;
	private @Getter @Setter String RecommendationSetup;
	private @Getter @Setter String Reporting;
	private @Getter @Setter String RestAccommodation;
	private @Getter @Setter String RestAuthority;
	private @Getter @Setter String RestAvail;
	private @Getter @Setter String RestCart;
	private @Getter @Setter String RestData;
	private @Getter @Setter String RestFinance;
	private @Getter @Setter String RestGroupMaster;
	private @Getter @Setter String RestGenerics;
	private @Getter @Setter String RestPackages;
	private @Getter @Setter String RestPromotion;
	private @Getter @Setter String RestQueue;
	private @Getter @Setter String RestSearch;
	private @Getter @Setter String RestSupplier;
	private @Getter @Setter String RestStandloneProduct;
	private @Getter @Setter String StandloneProductSetup;
	private @Getter @Setter String SupplierSetup;
	private @Getter @Setter String BookingManager;
	private @Getter @Setter String Utility;
	private @Getter @Setter String CentralLoading;
	private @Getter @Setter String Central;
	private @Getter @Setter String HazelCastAvail;
	private @Getter @Setter String HazelCastRoomRate;
}
