package com.serviceImpl;

import java.lang.reflect.Method;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.service.RetrieveHealthCheckService;

@Service
public class RetrieveHealthCheckServiceImpl implements RetrieveHealthCheckService{
	
	@Autowired
	private ApplicationContext applicationContext;
	
	@Override
	public String getHC(String site, String environment, String serviceName) throws Exception {
		
		String methodName = "get" + serviceName;
		Object bean = applicationContext.getBean("com.pojoConfiguration.AppConfiguration");
		Method method = bean.getClass().getMethod(methodName);
		String pUrl = (String)method.invoke(bean);
		return pUrl.replace("${env}.", environment.toLowerCase() +".").replace("${site}.", site.toLowerCase() + ".");
	}

}
